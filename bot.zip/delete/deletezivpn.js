const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function deletezivpn(username, serverId) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err || !server) return resolve('❌ Server tidak ditemukan.');

      const url = `http://${server.domain}:5888/deletezivpn?user=${username}&auth=${server.auth}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            return resolve(`✅ Akun UDP ZiVPN *${username}* telah dihapus.`);
          }
          resolve(`❌ Gagal: ${response.data.message}`);
        })
        .catch(err => resolve('❌ Koneksi API Gagal.'));
    });
  });
}

module.exports = { deletezivpn };