const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function checkzivpn(serverId) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err || !server) return resolve('❌ Server tidak ditemukan.');

      const url = `http://${server.domain}:5888/checkzivpn?auth=${server.auth}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const ziData = response.data.data;
            let msg = `🌟 *MONITOR UDP ZIVPN* 🌟\n`;
            ziData.forEach(user => {
              msg += `\n┌─────────────────────────────\n│ User: \`${user.user}\`\n│ Limit IP: \`${user.ip_limit}\`\n│ Status: \`${user.status}\`\n└─────────────────────────────\n`;
            });
            return resolve(msg + `\n✨ *Tunnel Official #TUNV2* ✨`);
          }
          resolve(`❌ Gagal: ${response.data.message}`);
        })
        .catch(err => resolve('❌ Server Offline atau API Error.'));
    });
  });
}

module.exports = { checkzivpn };