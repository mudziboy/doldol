const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function createzivpn(username, password, exp, iplimit, serverId) {
  console.log(`Creating UDP ZiVPN account for ${username} with expiry ${exp} days, IP limit ${iplimit}`); [cite: 17]
  
  // Validasi username agar sesuai standar keamanan sistem
  if (/\s/.test(username) || /[^a-zA-Z0-9]/.test(username)) { [cite: 17]
    return '❌ Username tidak valid. Mohon gunakan hanya huruf dan angka tanpa spasi.'; [cite: 17]
  }

  return new Promise((resolve, reject) => {
    // Ambil data server dari database sqlite bot 
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => { [cite: 17]
      if (err) {
        console.error('Error fetching server:', err.message); [cite: 17]
        return resolve('❌ Server tidak ditemukan. Silakan coba lagi.'); [cite: 17]
      }

      if (!server) return resolve('❌ Server tidak ditemukan. Silakan coba lagi.'); [cite: 17]

      const domain = server.domain; [cite: 17]
      const auth = server.auth; [cite: 17]
      
      // Memanggil endpoint API VPS yang akan kita buat di api.js nanti
      // Port menggunakan 5888 sesuai dengan standar api.js Anda 
      const param = `:5888/createzivpn?user=${username}&password=${password}&exp=${exp}&iplimit=${iplimit}&auth=${auth}`;
      const url = `http://${domain}${param}`; [cite: 17]

      axios.get(url)
        .then(response => {
          if (response.data.status === "success") { [cite: 17]
            const ziData = response.data.data;
            const msg = `
🌟 *AKUN UDP ZIVPN PREMIUM* 🌟

🔹 *Informasi Akun*
┌─────────────────────────────
│ Username : \`${ziData.username}\`
│ Password : \`${password}\`
│ Kadaluarsa: \`${ziData.expired}\`
│ Batas IP : \`${ziData.ip_limit} IP\`
└─────────────────────────────

🔹 *Detail Koneksi*
┌─────────────────────────────
│ Server IP : \`${ziData.ip}\`
│ Domain    : \`${ziData.domain}\`
│ Port UDP  : \`5667\`
│ Protokol  : \`UDP ZIVPN\`
│ Lokasi    : \`${ziData.city}\`
└─────────────────────────────

🔗 *Config Raw*
\`\`\`
udp://${ziData.domain}:5667@${ziData.username}:${password}
\`\`\`

✨ Terima kasih telah berlangganan! ✨
`; [cite: 17]
              console.log('ZiVPN account created successfully');
              return resolve(msg);
          } else {
              console.log('Error creating ZiVPN account');
              return resolve(`❌ Terjadi kesalahan: ${response.data.message}`); [cite: 17]
          }
        })
        .catch(error => {
          console.error('Error saat membuat ZiVPN:', error); [cite: 17]
          return resolve('❌ GAGAL! Tidak dapat terhubung ke API server. Pastikan API di VPS sudah berjalan.'); [cite: 17]
        });
    });
  });
}

module.exports = { createzivpn };