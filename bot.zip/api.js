const { spawn } = require("child_process");
const express = require("express");
const fs = require("fs");

const app = express();
app.use(express.json());

/* ======================================================
   CONFIG
====================================================== */
const AUTH_KEY_FILE = "/root/.key";
const PORT = process.env.PORT || 5888;

/* ======================================================
   UTIL: LOAD AUTH KEY
====================================================== */
function getAuthKey() {
  return fs.readFileSync(AUTH_KEY_FILE, "utf8").trim();
}

/* ======================================================
   AUTH MIDDLEWARE
====================================================== */
// Legacy auth (?auth=)
function legacyAuth(req, res, next) {
  try {
    if (req.query.auth !== getAuthKey()) {
      return res.status(401).json({ status: "error", message: "Unauthorized" });
    }
    next();
  } catch {
    res.status(500).json({ status: "error", message: "Auth config missing" });
  }
}

// Modern auth (X-API-Key)
function headerAuth(req, res, next) {
  try {
    if (req.headers["x-api-key"] !== getAuthKey()) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }
    next();
  } catch {
    res.status(500).json({ success: false, error: "Auth config missing" });
  }
}

/* ======================================================
   SAFE BINARY RUNNER (CORE)
====================================================== */
function runBinary(res, cmd, args) {
  const child = spawn(cmd, args, { timeout: 30000 });
  let output = "";

  child.stdout.on("data", d => output += d.toString());
  child.stderr.on("data", d => output += d.toString());

  child.on("close", () => {
    try {
      const json = JSON.parse(output);
      const ok = json.status === "success" || json.success === true;

      if (!ok) {
        return res.status(500).json({
          status: "error",
          message: json.message || "Operation failed"
        });
      }

      res.json({
        status: "success",
        data: json.data || json
      });
    } catch {
      res.status(500).json({
        status: "error",
        message: "Invalid service output",
        detail: output
      });
    }
  });
}

/* ======================================================
   GENERIC XRAY HANDLER (SSH / VMESS / VLESS / TROJAN / SS)
====================================================== */
function createXray(proto, req, res) {
  const { user, password, exp, quota, iplimit } = req.query;
  if (!user || !exp || !iplimit) {
    return res.status(400).json({ status: "error", message: "Invalid parameter" });
  }

  const args = ["apicreate", proto, user];
  if (password) args.push(password);
  args.push(exp);
  if (quota) args.push(quota);
  args.push(iplimit);

  runBinary(res, "bash", ["-c", args.join(" ")]);
}

function renewXray(proto, req, res) {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp) {
    return res.status(400).json({ status: "error", message: "Invalid parameter" });
  }

  const args = ["apirenew", proto, user, exp];
  if (quota) args.push(quota);
  if (iplimit) args.push(iplimit);

  runBinary(res, "bash", ["-c", args.join(" ")]);
}

function deleteXray(proto, req, res) {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ status: "error", message: "Invalid parameter" });
  }
  runBinary(res, "bash", ["-c", `apidelete ${proto} ${user}`]);
}

/* ======================================================
   XRAY LEGACY ENDPOINTS (BOT COMPAT)
====================================================== */
app.get("/createssh", legacyAuth, (req, res) => createXray("ssh", req, res));
app.get("/createvmess", legacyAuth, (req, res) => createXray("vmess", req, res));
app.get("/createvless", legacyAuth, (req, res) => createXray("vless", req, res));
app.get("/createtrojan", legacyAuth, (req, res) => createXray("trojan", req, res));
app.get("/createshadowsocks", legacyAuth, (req, res) => createXray("shadowsocks", req, res));

app.get("/renewssh", legacyAuth, (req, res) => renewXray("ssh", req, res));
app.get("/renewvmess", legacyAuth, (req, res) => renewXray("vmess", req, res));
app.get("/renewvless", legacyAuth, (req, res) => renewXray("vless", req, res));
app.get("/renewtrojan", legacyAuth, (req, res) => renewXray("trojan", req, res));
app.get("/renewshadowsocks", legacyAuth, (req, res) => renewXray("shadowsocks", req, res));

app.get("/deletessh", legacyAuth, (req, res) => deleteXray("ssh", req, res));
app.get("/deletevmess", legacyAuth, (req, res) => deleteXray("vmess", req, res));
app.get("/deletevless", legacyAuth, (req, res) => deleteXray("vless", req, res));
app.get("/deletetrojan", legacyAuth, (req, res) => deleteXray("trojan", req, res));
app.get("/deleteshadowsocks", legacyAuth, (req, res) => deleteXray("shadowsocks", req, res));

/* ======================================================
   ZIVPN CORE LOGIC
====================================================== */
function createZiVPN(res, password, days, ipLimit) {
  runBinary(res, "bash", ["/usr/bin/apicreate-zivpn", password, String(days), String(ipLimit)]);
}
function renewZiVPN(res, password, days) {
  runBinary(res, "bash", ["/usr/bin/apirenew-zivpn", password, String(days)]);
}
function deleteZiVPN(res, password) {
  runBinary(res, "bash", ["/usr/bin/apidelete-zivpn", password]);
}
function trialZiVPN(res, duration, ipLimit) {
  runBinary(res, "/usr/bin/apitrial-zivpn.real", [String(duration), String(ipLimit)]);
}

/* ======================================================
   ZIVPN LEGACY (BOT)
====================================================== */
app.get("/createzivpn", legacyAuth, (req, res) => {
  const { password, exp, iplimit } = req.query;
  if (!password || !exp || !iplimit) {
    return res.status(400).json({ status: "error", message: "Invalid parameter" });
  }
  createZiVPN(res, password, exp, iplimit);
});

app.get("/renewzivpn", legacyAuth, (req, res) => {
  const { password, exp } = req.query;
  if (!password || !exp) {
    return res.status(400).json({ status: "error", message: "Invalid parameter" });
  }
  renewZiVPN(res, password, exp);
});

app.get("/deletezivpn", legacyAuth, (req, res) => {
  const { password } = req.query;
  if (!password) {
    return res.status(400).json({ status: "error", message: "Invalid parameter" });
  }
  deleteZiVPN(res, password);
});

app.get("/apitrial-zivpn", legacyAuth, (req, res) => {
  const { duration = 60, iplimit = 2 } = req.query;
  trialZiVPN(res, duration, iplimit);
});

/* ======================================================
   ZIVPN API v2 (OFFICIAL COMPATIBILITY)
====================================================== */
app.post("/api/user/create", headerAuth, (req, res) => {
  const { password, days, ip_limit } = req.body;
  if (!password || !days || !ip_limit) {
    return res.status(400).json({ success: false, error: "Invalid payload" });
  }
  createZiVPN(res, password, days, ip_limit);
});

app.post("/api/user/renew", headerAuth, (req, res) => {
  const { password, days } = req.body;
  if (!password || !days) {
    return res.status(400).json({ success: false, error: "Invalid payload" });
  }
  renewZiVPN(res, password, days);
});

app.post("/api/user/delete", headerAuth, (req, res) => {
  const { password } = req.body;
  if (!password) {
    return res.status(400).json({ success: false, error: "Invalid payload" });
  }
  deleteZiVPN(res, password);
});

/* ======================================================
   HEALTH CHECK
====================================================== */
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "vpn-api-enterprise",
    port: PORT
  });
});

/* ======================================================
   START SERVER
====================================================== */
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Master VPN API Enterprise Ready on port ${PORT}`);
});