const os = require('os');
const { exec, execSync, spawn } = require('child_process');
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware untuk memeriksa kata sandi
const checkPassword = (req, res, next) => {
  const { auth } = req.query;
  try {
    const correctPassword = fs.readFileSync('/root/.key', 'utf8').trim();
    if (auth !== correctPassword) {
      return res.status(401).send('<html><body><h1 style="text-align: center;">Akses Ditolak</h1></body></html>');
    }
    next();
  } catch (err) {
    return res.status(500).send('Konfigurasi keamanan server (auth) tidak ditemukan.');
  }
};

app.use(checkPassword);

// ===============================
// 1. CREATE SSH
// ===============================
app.get("/createssh", (req, res) => {
  const { user, password, exp, iplimit } = req.query;
  if (!user || !password || !exp || !iplimit) {
    return res.status(400).json({ error: 'Parameter tidak lengkap' });
  }
  
  const child = spawn("/bin/bash", ["-c", `apicreate ssh ${user} ${password} ${exp} ${iplimit}`]);
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.on('close', (code) => {
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          data: {
            username: jsonResponse.data.username,
            password: jsonResponse.data.password,
            expired: jsonResponse.data.expired,            
            iplimit: jsonResponse.data.ip_limit || iplimit,
            domain: jsonResponse.data.domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey
          }
        });
      } else { res.status(500).json(jsonResponse); }
    } catch (err) { res.status(500).json({ error: "Parsing Error", detail: output }); }
  });
});

// ===============================
// 2. CREATE VMESS (FIX UNDEFINED)
// ===============================
app.get("/createvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  const child = spawn("/bin/bash", ["-c", `apicreate vmess ${user} ${exp} ${quota} ${iplimit}`]);
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.on('close', () => {
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            iplimit: jsonResponse.data.ip_limit || iplimit,
            domain: jsonResponse.data.domain,
            vmess_tls_link: jsonResponse.data.vmess_tls_link,
            vmess_nontls_link: jsonResponse.data.vmess_nontls_link,
            vmess_grpc_link: jsonResponse.data.vmess_grpc_link
          }
        });
      } else { res.status(500).json(jsonResponse); }
    } catch (e) { res.status(500).json({ error: "Error parsing output" }); }
  });
});

// ===============================
// 3. CREATE VLESS
// ===============================
app.get("/createvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  const child = spawn("/bin/bash", ["-c", `apicreate vless ${user} ${exp} ${quota} ${iplimit}`]);
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.on('close', () => {
    try {
      const jsonResponse = JSON.parse(output);
      res.json({
        status: "success",
        data: {
          ...jsonResponse.data,
          iplimit: jsonResponse.data.ip_limit || iplimit
        }
      });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

// ===============================
// 4. CREATE TROJAN
// ===============================
app.get("/createtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  const child = spawn("/bin/bash", ["-c", `apicreate trojan ${user} ${exp} ${quota} ${iplimit}`]);
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.on('close', () => {
    try {
      const jsonResponse = JSON.parse(output);
      res.json({
        status: "success",
        data: {
          ...jsonResponse.data,
          iplimit: jsonResponse.data.ip_limit || iplimit
        }
      });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

// ===============================
// 5. CREATE SHADOWSOCKS
// ===============================
app.get("/createshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  const child = spawn("/bin/bash", ["-c", `apicreate shadowsocks ${user} ${exp} ${quota} ${iplimit}`]);
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.on('close', () => {
    try {
      const jsonResponse = JSON.parse(output);
      res.json({
        status: "success",
        data: {
          ...jsonResponse.data,
          iplimit: jsonResponse.data.ip_limit || iplimit
        }
      });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

// ===============================
// 6. RENEW SERVICES
// ===============================
app.get("/renewssh", (req, res) => {
  const { user, exp, iplimit } = req.query;
  exec(`apirenew ssh ${user} ${exp} ${iplimit}`, (err, stdout) => {
    try {
      const j = JSON.parse(stdout);
      res.json({ status: "success", data: { username: j.data.username, expired: j.data.exp, iplimit: j.data.limitip } });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

app.get("/renewvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  exec(`apirenew vmess ${user} ${exp} ${quota} ${iplimit}`, (err, stdout) => {
    try {
      const j = JSON.parse(stdout);
      res.json({ status: "success", data: { username: j.data.username, expired: j.data.exp, quota: j.data.quota, iplimit: j.data.limitip } });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

app.get("/renewvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  exec(`apirenew vless ${user} ${exp} ${quota} ${iplimit}`, (err, stdout) => {
    try {
      const j = JSON.parse(stdout);
      res.json({ status: "success", data: { username: j.data.username, expired: j.data.exp, quota: j.data.quota, iplimit: j.data.limitip } });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

app.get("/renewtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  exec(`apirenew trojan ${user} ${exp} ${quota} ${iplimit}`, (err, stdout) => {
    try {
      const j = JSON.parse(stdout);
      res.json({ status: "success", data: { username: j.data.username, expired: j.data.exp, quota: j.data.quota, iplimit: j.data.limitip } });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

app.get("/renewshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  exec(`apirenew shadowsocks ${user} ${exp} ${quota} ${iplimit}`, (err, stdout) => {
    try {
      const j = JSON.parse(stdout);
      res.json({ status: "success", data: { username: j.data.username, expired: j.data.exp, quota: j.data.quota, iplimit: j.data.limitip } });
    } catch (e) { res.status(500).json({ error: "Error" }); }
  });
});

// ===============================
// 7. DELETE SERVICES
// ===============================
const deleteHandler = (proto, req, res) => {
  const { user } = req.query;
  exec(`apidelete ${proto} ${user}`, (err, stdout) => {
    try { res.json(JSON.parse(stdout)); } catch (e) { res.status(500).json({ error: "Delete failed" }); }
  });
};
app.get("/deletessh", (req, res) => deleteHandler('ssh', req, res));
app.get("/deletevmess", (req, res) => deleteHandler('vmess', req, res));
app.get("/deletevless", (req, res) => deleteHandler('vless', req, res));
app.get("/deletetrojan", (req, res) => deleteHandler('trojan', req, res));
app.get("/deleteshadowsocks", (req, res) => deleteHandler('shadowsocks', req, res));

// ===============================
// 8. ZIVPN UDP (FIXED FOR CORRECT BINARY)
// ===============================

// Create ZiVPN - Menggunakan apicreate-zivpn
app.get("/createzivpn", (req, res) => {
  const { password, exp, iplimit } = req.query;
  // Perbaikan: Memanggil apicreate-zivpn, bukan apicreate biasa
  exec(`bash /usr/bin/apicreate-zivpn ${password} ${exp} ${iplimit}`, (error, stdout) => {
    try { 
      res.json(JSON.parse(stdout)); 
    } catch (e) { 
      res.status(500).json({ status: "error", message: "Gagal membuat akun ZiVPN", detail: stdout }); 
    }
  });
});

// Renew ZiVPN - Untuk sinkronisasi menu Renew di Bot
app.get("/renewzivpn", (req, res) => {
  const { password, exp } = req.query;
  exec(`bash /usr/bin/apirenew-zivpn ${password} ${exp}`, (error, stdout) => {
    try { 
      res.json(JSON.parse(stdout)); 
    } catch (e) { 
      res.status(500).json({ status: "error", message: "Gagal memperbarui akun ZiVPN" }); 
    }
  });
});

// Delete ZiVPN - Untuk sinkronisasi penghapusan otomatis
app.get("/deletezivpn", (req, res) => {
  const { password } = req.query;
  exec(`bash /usr/bin/apidelete-zivpn ${password}`, (error, stdout) => {
    try { 
      res.json(JSON.parse(stdout)); 
    } catch (e) { 
      res.status(500).json({ status: "error", message: "Gagal menghapus akun ZiVPN" }); 
    }
  });
});

// Check ZiVPN - Untuk melihat data login member
app.get("/checkzivpn", (req, res) => {
  exec(`bash /usr/bin/apicheck-zivpn`, (error, stdout) => {
    try { 
      res.json(JSON.parse(stdout)); 
    } catch (e) { 
      res.status(500).json({ status: "error", message: "Gagal mengambil data member ZiVPN" }); 
    }
  });
});
// ===============================
// START SERVER
// ===============================
const PORT = process.env.PORT || 5888;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Master API Server Aktif pada Port ${PORT}`);
});